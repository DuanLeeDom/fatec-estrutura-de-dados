import java.util.Iterator;

import javax.management.RuntimeOperationsException;
import javax.naming.directory.InvalidAttributeValueException;

public class FilaGenerica<T> implements Iterable<T> {
    private T[] dados; // armazena o conteudo da fila
    private int ultimo;
    private int tamanho;
    private int movimentacoes;

    public FilaGenerica(int tamanho) {
        this.tamanho = tamanho;
        dados = (T[]) new Object[tamanho];
        ultimo = -1;
    }
    private boolean estaVazio(){
        return ultimo == -1;
    }

    private boolean estaCheio(){
        return numElementos() == tamanho;
    }
    public int numElementos(){
        return ultimo+1;
    }

    public void inserir(T info) throws InvalidAttributeValueException, RuntimeException{
        if (info == null){
            throw new InvalidAttributeValueException("Conteúdo não especificado.");
        }
        if(estaCheio()){
            throw new RuntimeException("Fila cheia.");
        }
        dados[++ultimo] = info;

    }

    public T remover() throws RuntimeException{
        if (estaVazio()){
            throw new RuntimeException("Fila vazia");
        }
        T aux = dados[0];
        moverParaFrente();
        return aux;
    }

    private void moverParaFrente() {
        movimentacoes = 0;
        for(int pos = 1 ; pos <= ultimo; pos++) {
            dados[pos-1] = dados[pos];
            movimentacoes++;
        }
        dados[ultimo--] = null;
    }

    public int getMovimentacoes(){
        return movimentacoes;
    }
    /*
    Rotina para obter um objeto que permita percorrer
    o conteúdo da lista
    */
    @Override
    public Iterator<T> iterator() {
        return new FilaGenericaIterator<T>(numElementos(),dados);
    }

    /*
    classe auxiliar para manipular a obtençao de elementos
    da fila sem ter qua acessar o fila diretamente.
    */
    private  class FilaGenericaIterator<T> implements Iterator<T>{
        private int indiceCorrente = 0;
        private final int tamanho;
        private T[] info;
        public FilaGenericaIterator(int qtd,T[] info) {
            tamanho = qtd;
            this.info = info;
        }

        /*
        Indica se existe elemento ainda não apresentado
        */
        @Override
        public boolean hasNext() {
            return indiceCorrente < tamanho;
        }

        /*
        Obtem o elemento da lista e posiciona no proximo
        */
        @Override
        public T next() {
            return (T) info[indiceCorrente++];
            
        }
    }

}
