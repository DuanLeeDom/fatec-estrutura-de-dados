public class Pessoa {
    private String ra;
    private String nome;
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((ra == null) ? 0 : ra.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Pessoa other = (Pessoa) obj;
        if (ra == null) {
            if (other.ra != null)
                return false;
        } else if (!ra.equals(other.ra))
            return false;
        return true;
    }


    
}
