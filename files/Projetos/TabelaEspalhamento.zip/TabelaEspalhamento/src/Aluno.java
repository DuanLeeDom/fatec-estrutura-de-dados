public class Aluno {
    private String ra;
    private String nome;

    public Aluno(String ra, String nome) {
        this.ra = ra;
        this.nome = nome;
    }
    
    public Aluno(String ra) {
        this.ra = ra;
        nome = "";
    }

    public Aluno() {
        ra ="";
        nome = "";
    }

    

    @Override
    public String toString() {
        return "Aluno [ra=" + ra + ", nome=" + nome + "]";
    }

    @Override
    public int hashCode() {
        //final int prime = 31;
        //int result = 1;
        //result = prime * result + ((ra == null) ? 0 : ra.hashCode());
        int result = (ra == null ? 0 : ra.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Aluno other = (Aluno) obj;
        if (ra == null) {
            if (other.ra != null)
                return false;
        } else if (!ra.equals(other.ra))
            return false;
        return true;
    }

    public String getRa() {
        return ra;
    }
    public void setRa(String ra) {
        this.ra = ra;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

    
}
