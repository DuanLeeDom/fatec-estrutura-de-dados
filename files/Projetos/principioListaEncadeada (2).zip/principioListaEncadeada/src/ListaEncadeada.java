public class ListaEncadeada<T> {
    Node<T> inicio = null;
    Node<T> fim = null;
    int elementos = 0;
    
    public ListaEncadeada() {
        inicio = null;
        fim = null;
        elementos = 0;
    }

    public boolean estaVazia(){
        return elementos == 0;
    }

    public int tamanho(){
        return elementos;
    }

    public void inserir(T conteudo){
        Node<T> novo = new Node<T>(conteudo);
        if (estaVazia()){
            inicio = novo;
            fim = novo;
        }
        else{
            fim.setProximo(novo);
            fim = novo;
        }
        elementos++;
    }

    public void inserirInicio(T conteudo){
        if (estaVazia()){
            inserir(conteudo);
        }
        else{
            Node<T> novo = new Node<T>(conteudo);
            novo.setProximo(inicio);
            inicio = novo;
            elementos++;
        }
    }
    public void inserirMeio(T conteudo, int posicao){
        if ((tamanho() < posicao) || (posicao < 1)){
            throw new IndexOutOfBoundsException("Posicao impossível");
        }
        if (posicao == 1){
            inserirInicio(conteudo);
        }
        else{
            Node<T> atual = inicio;
            for (int p = 1; p < (posicao-1); p++){
                atual = atual.getProximo();
            }
            Node<T> novo = new Node<T>(conteudo);
            novo.setProximo(atual.getProximo());
            atual.setProximo(novo);
            elementos++;
        }
    }

    public T remover(int posicao){
        T conteudo = null;
        if (estaVazia()){
            throw new ArrayIndexOutOfBoundsException("Lista vazia.");
        }
        if ( posicao < 1 || posicao > tamanho()){
            throw new ArrayIndexOutOfBoundsException("Posição inválida.");
        }
        if (posicao == 1){
            conteudo = inicio.getInfo();
            inicio = inicio.getProximo();
            if (inicio == null){
                fim = null;
            }
        }
        else{
            Node<T> atual = inicio;
            for (int p = 1; p < (posicao-1); p++){
                atual = atual.getProximo();
            }
            if (atual.getProximo() == fim){
                fim = atual;
            }
            conteudo = atual.getProximo().getInfo();
            atual.setProximo(atual.getProximo().getProximo());
        }
        elementos--;
        return conteudo;
    }

}
