import java.util.Iterator;

public class App {
    private static FilaGenerica<Integer> minhaFila;
    private static int somaMovimentacoes;
    public static void main(String[] args) throws Exception {
        System.out.println("Operação com Fila");
        int quantidade = 2500;
        minhaFila = new FilaGenerica<>(quantidade);
        for (int i = 1; i <= quantidade; i++){
            double numero = Math.random()*125;
            minhaFila.inserir((int) numero);
        }
        imprimeFila();
        System.out.println("Removendo da fila");
        try {
            while (minhaFila.numElementos()>0){
                System.out.print(minhaFila.remover());
                System.out.print(" => movimentações = ");
                System.out.println(minhaFila.getMovimentacoes());
                somaMovimentacoes += minhaFila.getMovimentacoes();
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        System.out.printf("Total de movimentações: %d \n",somaMovimentacoes );
        System.exit(0);


    }
    private static void imprimeFila() {
        System.out.println("Fila.");
        for (Iterator iterator = minhaFila.iterator(); iterator.hasNext();) {
            Integer info = (Integer) iterator.next();
            System.out.println(info);
            
        }
    }
}
