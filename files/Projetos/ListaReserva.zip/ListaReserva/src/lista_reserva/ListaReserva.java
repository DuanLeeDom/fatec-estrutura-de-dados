/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lista_reserva;

import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Luciano Pelissoli
 */
public class ListaReserva {
    static ListaGenerica<Reserva> minhalista = new ListaGenerica<Reserva>(20);
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        inserir();        
        imprimeLista();
        chamadas();
    }

    /*
        Rotina para simular o cadastro de diversas pessoas
        na lista de espera
    */
    private static void inserir() {
    try{
            minhalista.inserir(new Reserva("Joao","11-4587-5698",2));
            minhalista.inserir(new Reserva("Maria","11-4587-5600",2));
            minhalista.inserir(new Reserva("Fernando","11-4500-5611",5));
            minhalista.inserir(new Reserva("Juliana","11-98587-9998",4));
            minhalista.inserir(new Reserva("Sabrina","11-9599-5198",3));
            minhalista.inserir(new Reserva("Marcio","19-9987-1398",8));
        }
        catch(Exception e){            
        }
    }
    
    /*
    Rotina para apresentar as reservas em espera.
    */

    private static void imprimeLista() {
        System.out.println("Lista de espera.");
        for (Iterator iterator = minhalista.iterator(); iterator.hasNext();) {
            Reserva reserva = (Reserva) iterator.next();
            System.out.println(reserva);
            
        }
    }
    
    /*
    Rotina para simular a chamada de diversas reservas a partir
    do núnero de cadeiras que estão disponíveis
    */

    private static void chamadas() {
        System.out.println("Chamando com 5 -> " + busca(5));
        imprimeLista();
        System.out.println("Chamando com 10 -> " + busca(10));
        imprimeLista();
        System.out.println("Chamando com 2 -> " + busca(2));
        imprimeLista();
        System.out.println("Chamando com 8 -> " + busca(8));
        imprimeLista();
        System.out.println("Chamando com 2 -> " + busca(2));
        imprimeLista();
        System.out.println("Chamando com 6 -> " + busca(6));
        imprimeLista();
        System.out.println("Chamando com 10 -> " + busca(8));
        imprimeLista();
    }
    
    /*
    Rotina para simular o processo de verificação se uma reserva 
    que atenda ao número de lugares na mesa
    */
    private static Reserva busca(int lugares) {
        Reserva r = null;
        
        do{
            try {
                r = minhalista.localiza(Integer.valueOf(lugares));
                if (r != null && r.compareTo(Integer.valueOf(lugares))== 0){

                    minhalista.remover(r);
                    break;
                }
                else{
                    r = null;
                    lugares--;

                }
            } catch (Exception ex) {
                break;
            }

        }while (true);
            
        return r;
    }
    
}
