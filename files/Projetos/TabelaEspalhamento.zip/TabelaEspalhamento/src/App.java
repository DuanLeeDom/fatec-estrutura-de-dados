public class App {
    public static void main(String[] args) throws Exception {
        Hash<Aluno> meusDados = new Hash<Aluno>(4,0f);
        System.out.println("Fator de carga: " + meusDados.fatorCarga());
        try{
            Aluno teste = new Aluno("12345", "João");
            System.out.println("Inserir: " + teste);
            meusDados.inserir(teste);
            System.out.println("índice de colisões: " + meusDados.indiceColisao());
            teste = new Aluno("126745", "Maria");
            System.out.println("Inserir: " + teste);
            meusDados.inserir(teste);
            System.out.println("índice de colisões: " + meusDados.indiceColisao());
            
            teste = new Aluno("1erw2345", "Beltrano");
            System.out.println("Inserir: " + teste);
            meusDados.inserir(teste);
            System.out.println("índice de colisões: " + meusDados.indiceColisao());
            
            teste = new Aluno("345", "Ciclano");
            System.out.println("Inserir: " + teste);
            meusDados.inserir(teste);
            System.out.println("índice de colisões: " + meusDados.indiceColisao());
            
            teste = new Aluno("1dddd", "Joãozinho");
            System.out.println("Inserir: " + teste);
            meusDados.inserir(teste);
            System.out.println("índice de colisões: " + meusDados.indiceColisao());
        }
        catch(RuntimeException e){
            System.out.println(e.getMessage());
        }

        System.out.println("Buscas.");
        System.out.println(meusDados.busca(new Aluno("1dddd")));
        System.out.println("índice de colisões: " + meusDados.indiceColisao());

        System.out.println(meusDados.busca(new Aluno("12345")));
        System.out.println("índice de colisões: " + meusDados.indiceColisao());
        System.out.println(meusDados.busca(new Aluno("126745")));
        System.out.println("índice de colisões: " + meusDados.indiceColisao());
        System.out.println(meusDados.busca(new Aluno("1erw2345")));
        System.out.println("índice de colisões: " + meusDados.indiceColisao());

    }
}
