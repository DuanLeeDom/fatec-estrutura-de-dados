/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lista_reserva;

import java.util.Iterator;

/**
 *
 * @author Luciano Pelissoli
 */
public class ListaGenerica<T> implements Iterable<T>{
    
    private T[] lista;
    private int quantidade;
    
    //contrutor para criar o vetor com o tamnho desejado e
    // indicar que não tem elementos (quantidade = 0) e
    // indica o indice (quantidade) que receberá o conteudo 
    
    public ListaGenerica(int tamanho){
        lista =(T[]) new Object[tamanho];
        quantidade = 0;
    }
    /*
    Insere um conteudo se a lista não estiver cheia.
    Atualiza a quantidade e por conseguinte a procima posição
    para inserir o proximo conteúdo
    */
    public void inserir(T objeto) throws Exception{
        if(cheio()){
            throw new Exception("Lista Cheia");
        }
        lista[quantidade] = objeto;
        quantidade++;
    }
    
    /*
    Devolve o conteúdo que está quandado em um posição
    no vetor, se a posição for válida
    */
    public T consultar(int posicao) throws Exception{
        if (posicao < 0 || posicao >= quantidade){
            throw new Exception("Posicao inválida");
        }
        if (vazia()){
            throw new Exception("Lista vazia.");
        }
        return lista[posicao];
    }
    
    /*
    Localiza um conteúdo dentro da lista, segundo a 
    regra de igualdade estabelecida na classe utilizada no vetor
    */
    public T localiza(Object o){
        T retorno = null;
        for (T t : lista) {
            if (t == null){
                break;
            }
            if (t.equals(o)){
                retorno = t;
                break;
            }            
        }
        return retorno;
    }
    
    public T remover(Object o) throws Exception{
        
        for(int indice = 0 ; indice < quantidade ; indice++){
            if (lista[indice].equals(o)){
                return remover(indice);
            }
        }
        return null;
    }
    /*
    Remove um elmento do vetor e movimenta todos os elementos posterior
    para a posição anterior.
    Devolve o elemento que foi removido.
    */
    
    public T remover(int posicao) throws Exception{
        if (posicao < 0 || posicao >= quantidade){
            throw new Exception("Posição Invalida");
        }
        if (vazia()){
            throw new Exception("Lista Vazia");
        }
        T retorno = lista[posicao];
        for (int i = posicao; i < (quantidade -1); i++){
            lista[i] = lista[i+1];
        }
        lista[--quantidade] = null;
        return retorno;
        
    }

    /*
    Indica se a lista está cheia
    */
    private boolean cheio() {
        return quantidade == lista.length;
    }

    /*
    Indice se a lista está vazia
    */
    private boolean vazia() {
        return quantidade == 0;
    }

    /*
    Rotina para obter um objeto que permita percorrer
    o conteúdo da lista
    */
    @Override
    public Iterator<T> iterator() {
        return new ListaGenericaIterator<T>(quantidade);
    }

    /*
    classe auxiliar para manipular a obtençao de elementos
    da lista sem ter qua acessar o lista diretamente.
    */
    private  class ListaGenericaIterator<T> implements Iterator<T>{
        private int indiceCorrente = 0;
        private final int tamanho;
        public ListaGenericaIterator(int qtd) {
            tamanho = qtd;
        }

        /*
        Indica se existe elemento ainda não apresentado
        */
        @Override
        public boolean hasNext() {
            return indiceCorrente < tamanho;
        }

        /*
        Obtem o elemento da lista e posiciona no proximo
        */
        @Override
        public T next() {
            return (T) lista[indiceCorrente++];
            
        }
    }
    
    
}
