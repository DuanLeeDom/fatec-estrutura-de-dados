import java.time.Duration;
import java.time.LocalTime;
import java.util.Iterator;

import javax.management.InvalidAttributeValueException;

public class App {
    private static FilaGenerica<Integer> minhaFila;
    private static int somaMovimentacoes;
    public static void main(String[] args) throws Exception {
        LocalTime fim, inicio = LocalTime.now();
        System.out.println("Operação com Fila");
        int quantidade = 100000;
        minhaFila = new FilaGenerica<>(quantidade);
        inserir(quantidade);
        
        imprimeFila();
        System.out.println("Removendo da fila");
       
        remover(quantidade);
        fim = LocalTime.now();
        System.out.printf("Total de movimentações: %d \n",somaMovimentacoes );
        System.out.println("Hora inicial: " + inicio);
        System.out.println("Hora final: " + fim);
        System.out.print("Tempo decorrido. ");
        System.out.println(Duration.between(inicio, fim));
        System.exit(0);


    }
    private static void remover(int quantidade) {
         try {
            while (minhaFila.numElementos()>0){
                System.out.print(minhaFila.remover());
                System.out.print(" => movimentações = ");
                System.out.println(minhaFila.getMovimentacoes());
                somaMovimentacoes += minhaFila.getMovimentacoes();
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    private static void imprimeFila() {
        System.out.println("Fila.");
        for (Iterator iterator = minhaFila.iterator(); iterator.hasNext();) {
            Integer aux = (Integer) iterator.next();
            System.out.println(aux);
        }
    }
    private static void inserir(int quantidade) {
        for (int i = 1; i <= quantidade; i++){
            double numero = Math.random()*125;
            try {
                minhaFila.inserir((int) numero);
            } catch (javax.naming.directory.InvalidAttributeValueException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (RuntimeException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

    }
}
