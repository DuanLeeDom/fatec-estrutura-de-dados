import java.text.RuleBasedCollator;
import java.util.Iterator;

public class App {

    static PilhaGenerica<Integer> minhapilha;
    public static void main(String[] args) throws Exception {
        minhapilha = new PilhaGenerica<Integer>(10);   
        int x = 0;
        do{
            x = (int) (Math.random()*100);
        }while (insere(x));
        
        

        System.out.println("lista o conteudo da pilha");
        exibir();
        System.out.println("Desemplilhando");
        System.out.println("Consula topo: " + minhapilha.consultar());
        exibirRemocao(minhapilha);
        exibirRemocao(minhapilha);
        exibirRemocao(minhapilha);
        exibirRemocao(minhapilha);
        exibirRemocao(minhapilha);

        
        

    }
    private static boolean insere(int x) {
        try{
            minhapilha.empilhar(x);
            System.out.println("Empilhando o valor " + x);
            return true;
        }
        catch (RuntimeException e){
            System.out.println(e.getMessage());
        }
        return false;
    }
    private static void exibirRemocao(PilhaGenerica<Integer> dados) {
        try{
            System.out.println("Removeu: "+ dados.desempilha());
        }
        catch(RuntimeException e){
            System.out.println(e.getMessage());
        }
    }
    private static void exibir() {
        for (Iterator<Integer> x = minhapilha.iterator(); x.hasNext();){
            System.out.println(x.next());
        }
        
    }
}
