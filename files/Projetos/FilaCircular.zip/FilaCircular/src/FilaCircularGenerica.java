import java.util.Iterator;


import javax.naming.directory.InvalidAttributeValueException;

public class FilaCircularGenerica<T> implements Iterable<T> {
    private T[] dados; // armazena o conteudo da fila
    private int ultimo;
    private int primeiro;
    private int tamanho;
    private int quantidade;
    private long movimentacoes;

    public FilaCircularGenerica(int tamanho) {
        this.tamanho = tamanho;
        dados = (T[]) new Object[tamanho];
        ultimo = -1;
        primeiro = -1;
        quantidade = 0;
    }
    private boolean estaVazio(){
        if(quantidade == 0){
            ultimo = -1;
            primeiro = -1;
        }
        return quantidade == 0;
    }

    private boolean estaCheio(){
        return numElementos() == tamanho;
    }
    public int numElementos(){
        return quantidade;
    }

    public void inserir(T info) throws InvalidAttributeValueException, RuntimeException{
        if (info == null){
            throw new InvalidAttributeValueException("Conteúdo não especificado.");
        }
        if(estaCheio()){
            throw new RuntimeException("Fila cheia.");
        }
        if(estaVazio()){
            primeiro = 0;
        }
        
        ultimo = (ultimo+1) % tamanho; 
        dados[ultimo] = info;  
        quantidade++; 

    }

    public T remover() throws RuntimeException{
        movimentacoes = 0;
        if (estaVazio()){
            throw new RuntimeException("Fila vazia");
        }
        T aux = dados[primeiro];
        dados[primeiro] = null;
        quantidade--;
        primeiro = (primeiro + 1) % tamanho;
        movimentacoes++;
        
        return aux;
    }

    

    public long getMovimentacoes(){
        return movimentacoes;
    }
    /*
    Rotina para obter um objeto que permita percorrer
    o conteúdo da lista
    */
    @Override
    public Iterator<T> iterator() {
        return new FilaCircularGenericaIterator<T>(numElementos(),dados);
    }

    /*
    classe auxiliar para manipular a obtençao de elementos
    da fila sem ter qua acessar o fila diretamente.
    */
    private  class FilaCircularGenericaIterator<T> implements Iterator<T>{
        private int indiceCorrente = 0;
        private int quantidade;
        private T[] info;
        public FilaCircularGenericaIterator(int qtd,T[] info) {
            quantidade = qtd;
            this.info = info;
            indiceCorrente = primeiro;
        }

        /*
        Indica se existe elemento ainda não apresentado
        */
        @Override
        public boolean hasNext() {
            return quantidade > 0 ;
        }

        /*
        Obtem o elemento da lista e posiciona no proximo
        */
        @Override
        public T next() {
            quantidade--;
            T aux = (T)info[indiceCorrente];
            indiceCorrente = (indiceCorrente+1) % tamanho;
            return aux ;
            
        }
    }

}
