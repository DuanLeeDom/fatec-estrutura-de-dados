

public class Hash<T> {
    private T[] dados;
    private int tamanho;
    private int colisao;
    private int elementos;
   
    public Hash(int tamanho, float fatorCarga) {
        colisao = 0;
        elementos = 0;
        this.tamanho = tamanho;
        dados = (T[]) new Object[(int) (tamanho * (1+fatorCarga))]; 
    }

    public float fatorCarga(){
        float f = tamanho / dados.length; 
        return f;
    }
    private boolean estaCheio(){
        return elementos == dados.length;
    }

    private boolean estaVazio(){
        return elementos == 0;
    }

    private int indiceHash(int hash){
        return Math.abs(hash % (dados.length));
    }

    private int colisao(int hash){
        
        while (dados[hash] != null){
            colisao++;
            hash = indiceHash(hash+1);
        }
        return hash;
    }

    public void inserir(T objeto) throws RuntimeException{
        if (!estaCheio()){
            colisao = 0;
            int indice = indiceHash(objeto.hashCode());
            indice = colisao(indice);
            dados[indice] = objeto;
            elementos++;
        }
        else{
            throw new RuntimeException("Tabela de espalhamento cheia.");
        }
    }

    public T busca(T objeto){  
        if (estaVazio()){
            return null;
        }
        colisao = 0;

        int hash = indiceHash(objeto.hashCode());
        
        while (dados[hash] != null && !((T)dados[hash]).equals(objeto)){
            hash = indiceHash(hash+1);
            colisao++;
            // se o número de colisao for maior que o tamanho do vetor
            // significa que o vetor está cheio e o dado não foi encontrado. 
            if (colisao == dados.length){
                return null;
            }
        }
        return dados[hash];
    }

    public int indiceColisao() {
        return colisao;
    }
}
