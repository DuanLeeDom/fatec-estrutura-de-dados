/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lista_reserva;

import java.util.Iterator;
import java.util.Objects;
import java.util.function.Consumer;

/**
 *
 * @author Luciano Pelissoli
 */
public class Reserva implements Comparable<Object>{
    private String nome;
    private String telefone;
    private int acompanhantes;

    public Reserva(String nome, String telefone, int acompanhantes) {
        this.nome = nome;
        this.telefone = telefone;
        this.acompanhantes = acompanhantes;
    }

    @Override
    public String toString() {
        return "Reserva{" + "nome=" + nome + ", telefone=" + telefone + ", acompanhantes=" + acompanhantes + '}';
    }
    
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            if (obj.getClass() != Integer.class){
                return false;
            }
            final Integer other = (Integer) obj;
            return this.acompanhantes == other;
        }
        final Reserva other = (Reserva) obj;
        return this.acompanhantes == other.acompanhantes ;
        
    }

   
    @Override
    public int compareTo(Object o) {
        if (o == null){
            throw new IllegalArgumentException("Informe um objeto");
        }
        if (this == o){
            return 0;
        }
        
        Integer outro = (Integer) o;
        return this.acompanhantes - outro.intValue();
    }

    
}